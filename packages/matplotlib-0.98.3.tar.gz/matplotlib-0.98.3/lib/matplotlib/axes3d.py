raise NotImplmentedError('axes3d is not supported in matplotlib-0.98.  You may want to try the 0.91.x maintenance branch')
