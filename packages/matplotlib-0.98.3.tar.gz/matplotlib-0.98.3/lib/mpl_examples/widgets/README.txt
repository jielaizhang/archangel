Examples of how to write primitive, but GUI agnoistic, widgets in
matplotlib
